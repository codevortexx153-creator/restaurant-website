GitHub repo size GitHub stars GitHub forks Twitter Follow YouTube Video Views



Grilli - Restaurant Website
Grilli is a fully responsive restaurant website,
Responsive for all devices, build using HTML, CSS, and JavaScript.

➥ Live Demo


Demo Screeshots
Grilli Desktop Demo

Prerequisites
Before you begin, ensure you have met the following requirements:

Git must be installed on your operating system.
Run Locally
To run Grilli locally, run this command on your git bash:

Linux and macOS:

sudo git clone https://github.com/codewithsadee/grilli.git
Windows:

git clone https://github.com/codewithsadee/grilli.git
Contact
If you want to contact with me you can reach me at Twitter.

License
MIT